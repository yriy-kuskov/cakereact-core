export { CakeReact } from './CakeReactCore';
// Экспортируем всё основное отсюда, чтобы было удобно импортировать
export * from './Model';
export * from './Utils';
export * from './Controller';
export * from './Components';