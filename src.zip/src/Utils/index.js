// Импортируем и тут же экспортируем
export * from './ImageOptimizer';